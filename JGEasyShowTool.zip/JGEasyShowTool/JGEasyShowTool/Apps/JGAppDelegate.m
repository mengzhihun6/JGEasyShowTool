//
//  JGAppDelegate.m
//  JGEasyShowTool
//
//  Created by 郭军 on 2018/1/9.
//  Copyright © 2018年 郭军. All rights reserved.
//

#import "JGAppDelegate.h"
#import "JGTabbarController.h"
#import "JGEasyShowOptions.h"


//#import "LEEAlert.h"


@interface JGAppDelegate ()

@end


@implementation JGAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    //创建新窗口
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    //设置窗口的根控制器
    self.window.rootViewController = [[JGTabbarController alloc] init];
    //让窗口可见
    [self.window makeKeyAndVisible];
    
    //弹框配置
    [self loadEasyShowTool];
    
    return YES;
}


/**
 弹框配置
 */
- (void)loadEasyShowTool {
    
    //弹框配置
    JGEasyShowOptions *options = [JGEasyShowOptions sharedEasyShowOptions];
    options.textSuperViewReceiveEvent = YES ;
    
    //动画图
    NSMutableArray *tempArray = [NSMutableArray arrayWithCapacity:7];
    for (int i = 0; i < 9 ; i++) {
        NSString *tempString = [NSString stringWithFormat:@"icon_hud_%zd",i+1];
        [tempArray addObject:[UIImage imageNamed:tempString]];
    }
    options.lodingPlayImagesArray = [NSArray arrayWithArray:tempArray ];
    
    
    //ALert AND ActionSheet 设置主window  (经测试 不设置 目前没有影响)
//    [LEEAlert configMainWindow:self.window];

}




- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
