//
//  JGEasyShowTextBgView.h
//  JGEasyShowTool
//
//  Created by 郭军 on 2018/1/10.
//  Copyright © 2018年 郭军. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "JGEasyShowOptions.h"

@interface JGEasyShowTextBgView : UIView

- (instancetype)initWithFrame:(CGRect)frame status:(ShowTextStatus)status text:(NSString *)text imageName:(NSString *)imageName;

- (void)showWindowYToPoint:(CGFloat)toPoint ;

- (void)showStartAnimationWithDuration:(CGFloat)duration ;
- (void)showEndAnimationWithDuration:(CGFloat)duration  ;


@end
