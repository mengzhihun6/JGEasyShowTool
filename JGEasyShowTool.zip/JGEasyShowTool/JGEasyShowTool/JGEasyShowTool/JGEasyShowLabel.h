//
//  JGEasyShowLabel.h
//  JGEasyShowTool
//
//  Created by 郭军 on 2018/1/10.
//  Copyright © 2018年 郭军. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JGEasyShowLabel : UILabel

- (instancetype)initWithContentInset:(UIEdgeInsets)contentInset ;


@end
