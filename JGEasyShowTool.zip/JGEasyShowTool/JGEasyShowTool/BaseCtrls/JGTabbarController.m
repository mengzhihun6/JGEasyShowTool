//
//  JGTabbarController.m
//  JGEasyShowTool
//
//  Created by 郭军 on 2018/3/14.
//  Copyright © 2018年 郭军. All rights reserved.
//

#import "JGTabbarController.h"
#import "JGNavigationController.h"

#import "JGShowFuncController.h"
#import "JGAlertViewController.h"
#import "JGActionSheetController.h"

@interface JGTabbarController ()

@end

@implementation JGTabbarController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self setupChildVc:[[JGShowFuncController alloc] init] title:@"ShowTool" image:@"tabBar_friendTrends_icon"  selectedImage:@"tabBar_friendTrends_click_icon"];
    
    [self setupChildVc:[[JGAlertViewController alloc] init] title:@"Alert" image:@"tabBar_new_icon" selectedImage:@"tabBar_new_click_icon"];
    
    [self setupChildVc:[[JGActionSheetController alloc] init] title:@"ActionSheet" image:@"tabBar_me_icon" selectedImage:@"tabBar_me_click_icon"];
    
}

/**
 *  初始化控制器
 *
 *  @param vc            控制器
 *  @param title         标题
 *  @param image         图片
 *  @param selectedImage 选中图片
 */
- (void)setupChildVc:(UIViewController *)vc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage {
    
    vc.navigationItem.title = title;
    vc.tabBarItem.title = title;
    vc.tabBarItem.image = [UIImage imageNamed:image];
    vc.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    //包装一个导航控制器
    JGNavigationController *nav = [[JGNavigationController alloc] initWithRootViewController:vc];
    //隐藏tabbar
    [self addChildViewController:nav];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
