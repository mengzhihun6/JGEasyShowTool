//
//  JGTabbarController.h
//  JGEasyShowTool
//
//  Created by 郭军 on 2018/3/14.
//  Copyright © 2018年 郭军. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JGTabbarController : UITabBarController

@end
