//
//  main.m
//  JGEasyShowTool
//
//  Created by 郭军 on 2018/1/10.
//  Copyright © 2018年 郭军. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JGAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([JGAppDelegate class]));
    }
}
