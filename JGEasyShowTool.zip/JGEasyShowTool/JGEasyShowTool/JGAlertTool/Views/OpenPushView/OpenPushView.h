//
//  OpenPushView.h
//  Headlines
//
//  Created by 李响 on 2017/1/19.
//  Copyright © 2017年 ck. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OpenPushView : UIView

/**
 *  关闭Block
 */
@property (nonatomic , copy ) void (^closeBlock)();

@end
